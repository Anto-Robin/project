-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: e_commerce_app
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `u_id` int NOT NULL AUTO_INCREMENT,
  `u_name` varchar(100) DEFAULT NULL,
  `u_email` varchar(100) NOT NULL,
  `u_pass` varchar(20) NOT NULL,
  `u_type` varchar(2) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (101,'Alice Johnson','alice.johnson@example.com','pass101','c'),(102,'Bob Smith','bob.smith@example.com','pass102','c'),(103,'Charlie Brown','charlie.brown@example.com','pass103','c'),(104,'Diana Prince','diana.prince@example.com','pass104','c'),(105,'Ethan Hunt','ethan.hunt@example.com','pass105','c'),(106,'Fiona Davis','fiona.davis@example.com','pass106','c'),(107,'George Miller','george.miller@example.com','pass107','c'),(108,'Hannah Wilson','hannah.wilson@example.com','pass108','c'),(109,'Ian Clark','ian.clark@example.com','pass109','c'),(110,'Julia Roberts','julia.roberts@example.com','pass110','c'),(111,'Kevin Lee','kevin.lee@example.com','pass111','c'),(112,'Laura Scott','laura.scott@example.com','pass112','c'),(113,'Michael Adams','michael.adams@example.com','pass113','c'),(114,'Nina Turner','nina.turner@example.com','pass114','c'),(115,'Oscar White','oscar.white@example.com','pass115','c'),(116,'Paula Green','paula.green@example.com','pass116','c'),(117,'Quentin Hall','quentin.hall@example.com','pass117','c'),(118,'Rachel King','rachel.king@example.com','pass118','c'),(119,'Sam Young','sam.young@example.com','pass119','c'),(120,'Tina Brooks','tina.brooks@example.com','pass120','c'),(121,'Umar Khan','umar.khan@example.com','pass121','c'),(122,'Vera Cruz','vera.cruz@example.com','pass122','c'),(123,'Will Grant','will.grant@example.com','pass123','c'),(124,'Xavier Lopez','xavier.lopez@example.com','pass124','c'),(125,'Yara Patel','yara.patel@example.com','pass125','c'),(126,'Zane Morris','zane.morris@example.com','pass126','c'),(127,'Adam Reed','adam.reed@example.com','pass127','c'),(128,'Bella Shaw','bella.shaw@example.com','pass128','c'),(129,'Carl Evans','carl.evans@example.com','pass129','c'),(130,'Dana Fox','dana.fox@example.com','pass130','c'),(131,'Eli Ward','eli.ward@example.com','pass131','c'),(132,'Faith Hill','faith.hill@example.com','pass132','c'),(133,'Gavin Ross','gavin.ross@example.com','pass133','c'),(134,'Hazel Price','hazel.price@example.com','pass134','c'),(135,'Isaac Bell','isaac.bell@example.com','pass135','c'),(136,'Jade West','jade.west@example.com','pass136','c'),(137,'Kyle Stone','kyle.stone@example.com','pass137','c'),(138,'Lily Carter','lily.carter@example.com','pass138','c'),(139,'Mark Fisher','mark.fisher@example.com','pass139','c'),(140,'Nora Blake','nora.blake@example.com','pass140','c'),(141,'Owen Perry','owen.perry@example.com','pass141','c'),(142,'Penny Ross','penny.ross@example.com','pass142','c'),(143,'Raymond Scott','raymond.scott@example.com','pass143','c'),(144,'Sophie Lane','sophie.lane@example.com','pass144','c'),(145,'Tom Hardy','tom.hardy@example.com','pass145','c'),(146,'Uma Stone','uma.stone@example.com','pass146','c'),(147,'Victor Cruz','victor.cruz@example.com','pass147','c'),(148,'Wendy Adams','wendy.adams@example.com','pass148','c'),(149,'Xena Ray','xena.ray@example.com','pass149','c'),(150,'Yusuf Ali','yusuf.ali@example.com','pass150','c'),(151,'admin','admin@mphasis.com','admin123','a'),(152,'Akash','akash@mphasis.com','akash123','c'),(153,'odiki','odiki@mphasis.com','odiki69','c'),(154,'Sesha','seshavarshan02@gmail.com','sesha123','c'),(155,'Odiki','sathyaloki8@gmail.com','odiki123','c');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-16 11:31:22
