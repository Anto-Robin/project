package servlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.ProductDAO;
import model.Product;

@WebServlet("/SearchProduct")
public class SearchProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.trim().equals("a")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String query = request.getParameter("q");
        ProductDAO dao = new ProductDAO();
        List<Product> products;

        if (query != null && !query.trim().isEmpty()) {
            products = dao.searchProducts(query.trim());
        } else {
            products = dao.getAllProducts();
        }

        // Update session so AdminDashboard.jsp renders correct list
        session.setAttribute("products", products);
        request.getRequestDispatcher("/AdminDashboard.jsp").forward(request, response);
    }
}
