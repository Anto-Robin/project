package servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ImageServlet — serves image files from the webapp/image/ folder.
 *
 * URL pattern : /image/*
 * Example URL : /ecommerce-application/image/books/Harry_Potter.jpg
 * Reads from  : [webapp root]/image/books/Harry_Potter.jpg
 */
@WebServlet("/image/*")
public class ImageServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // e.g. pathInfo = "/books/Harry_Potter.jpg"
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || pathInfo.equals("/")) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        // Security: block path traversal attacks (e.g. ../../etc/passwd)
        if (pathInfo.contains("..")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        // Build absolute path to the image file on disk
        // getRealPath("/image") → absolute path of webapp/image/ folder
        String imageFolderPath = getServletContext().getRealPath("/image");
        File imageFile = new File(imageFolderPath, pathInfo);

        if (!imageFile.exists() || !imageFile.isFile()) {
            // Try alternate: src/image/ folder (Eclipse sometimes puts it there)
            String srcImagePath = getServletContext().getRealPath("/") 
                                  + "../../image" + pathInfo;
            File altFile = new File(srcImagePath);
            if (altFile.exists() && altFile.isFile()) {
                imageFile = altFile;
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND,
                        "Image not found: " + pathInfo);
                return;
            }
        }

        // Set correct content type based on file extension
        String fileName = imageFile.getName().toLowerCase();
        String contentType;
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) {
            contentType = "image/jpeg";
        } else if (fileName.endsWith(".png")) {
            contentType = "image/png";
        } else if (fileName.endsWith(".gif")) {
            contentType = "image/gif";
        } else if (fileName.endsWith(".webp")) {
            contentType = "image/webp";
        } else if (fileName.endsWith(".avif")) {
            contentType = "image/avif";
        } else {
            contentType = "application/octet-stream";
        }

        response.setContentType(contentType);
        response.setContentLengthLong(imageFile.length());

        // Stream the image bytes to the response
        try (FileInputStream in = new FileInputStream(imageFile);
             OutputStream out = response.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }
}
