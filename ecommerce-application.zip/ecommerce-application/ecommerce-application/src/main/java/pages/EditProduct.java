package pages;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.ProductDAO;
import model.Product;

@WebServlet("/edit")
public class EditProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.trim().equals("a")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            int    id       = Integer.parseInt(request.getParameter("productId"));
            String name     = request.getParameter("productName");
            String category = request.getParameter("productCategory");
            String desc     = request.getParameter("productDescription");
            int    qty      = Integer.parseInt(request.getParameter("productQuantity"));
            double price    = Double.parseDouble(request.getParameter("productPrice"));
            String image    = request.getParameter("productImage"); // ✅ FIX: read image

            // If admin cleared the image field, keep existing DB value
            // by fetching the old product first
            if (image == null || image.trim().isEmpty()) {
                ProductDAO dao = new ProductDAO();
                Product existing = dao.getByProductId(id);
                if (existing != null && existing.getImage() != null) {
                    image = existing.getImage();
                } else {
                    // fallback: auto-generate
                    image = category.trim() + "/" + name.trim().replace(" ", "_") + ".jpg";
                }
            }

            Product p = new Product();
            p.setProductId(id);
            p.setProductName(name.trim());
            p.setProductCategory(category.trim());
            p.setProductDescription(desc.trim());
            p.setProductQuantity(qty);
            p.setProductPrice(price);
            p.setImage(image.trim()); // ✅ FIX: set image so it's saved

            ProductDAO dao = new ProductDAO();
            dao.update(p);

            response.sendRedirect(request.getContextPath()
                    + "/AdminDashboard?success=updated");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath()
                    + "/AdminDashboard?error=error");
        }
    }
}